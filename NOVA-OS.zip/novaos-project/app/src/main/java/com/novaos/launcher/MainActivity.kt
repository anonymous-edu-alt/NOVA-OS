package com.novaos.launcher

import android.app.ActivityManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

private val Forest = Color(0xFF147D62)
private val Ink = Color(0xFF17231F)
private val Canvas = Color(0xFFF4F7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

data class DeviceStats(val battery: Int, val charging: Boolean, val freeStorage: String, val totalStorage: String, val availableRam: String)
data class LaunchApp(val title: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

@Composable
fun NovaApp() {
    val context = LocalContext.current
    var stats by remember { mutableStateOf(readStats(context)) }
    var tab by remember { mutableStateOf(0) }
    var dark by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(loadApps(context)) }
    var search by remember { mutableStateOf("") }
    val bg = if (dark) Color(0xFF101815) else Canvas
    val surface = if (dark) Color(0xFF1B2722) else Color.White
    val primaryText = if (dark) Color(0xFFE8F0EB) else Ink
    val secondaryText = if (dark) Color(0xFFB1C1B8) else Color(0xFF718078)

    LaunchedEffect(Unit) {
        while (true) { stats = readStats(context); delay(15_000) }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF65D6B0), background = bg, surface = surface) else lightColorScheme(primary = Forest, background = bg, surface = surface)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar(containerColor = surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1; apps = loadApps(context) }, icon = { Icon(Icons.Default.GridView, null) }, label = { Text("Apps") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Settings") })
            }
        }) { padding ->
            when (tab) {
                0 -> HomeScreen(stats, surface, primaryText, secondaryText, dark, { tab = 1 }, { tab = 2 }, Modifier.padding(padding))
                1 -> AppsScreen(apps, search, { search = it }, primaryText, secondaryText, Modifier.padding(padding))
                else -> SettingsScreen(dark, { dark = it }, primaryText, secondaryText, surface, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomeScreen(s: DeviceStats, surface: Color, text: Color, muted: Color, dark: Boolean, openApps: () -> Unit, openSettings: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NOVA OS", color = Forest, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Your space. Your flow.", color = text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.size(46.dp).clip(CircleShape).background(Forest), contentAlignment = Alignment.Center) { Text("N", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 23.sp) }
        }
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF203C32) else Color(0xFFE1F1E9)), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp)) {
                Text("DEVICE OVERVIEW", color = if (dark) Color(0xFFBDE8D2) else Forest, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BatteryChargingFull, null, tint = Forest, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text("${s.battery}%", color = text, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(if (s.charging) "Charging" else "Battery level", color = muted, fontSize = 13.sp) }
                    Text("OPPO-ready", color = Forest, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(progress = { s.battery.coerceIn(0,100) / 100f }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = Forest, trackColor = if (dark) Color(0xFF3C574B) else Color(0xFFC5DDCF))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Storage free", s.freeStorage, Icons.Default.Storage, surface, text, muted, Modifier.weight(1f))
            MetricCard("RAM available", s.availableRam, Icons.Default.Memory, surface, text, muted, Modifier.weight(1f))
        }
        Spacer(Modifier.height(22.dp))
        Text("Quick actions", color = text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val actions = listOf(Triple("Wi-Fi", Icons.Default.Wifi, Settings.ACTION_WIFI_SETTINGS), Triple("Bluetooth", Icons.Default.Bluetooth, Settings.ACTION_BLUETOOTH_SETTINGS), Triple("Display", Icons.Default.Brightness6, Settings.ACTION_DISPLAY_SETTINGS), Triple("Sound", Icons.Default.VolumeUp, Settings.ACTION_SOUND_SETTINGS))
        actions.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                row.forEach { (label, icon, action) -> ActionCard(label, icon, surface, text, muted, Modifier.weight(1f)) { context.startActivity(Intent(action)) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Built for Android · No root", color = muted, fontSize = 11.sp)
            Text("v0.1.0", color = muted, fontSize = 11.sp)
        }
    }
}

@Composable private fun MetricCard(title: String, value: String, icon: ImageVector, surface: Color, text: Color, muted: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Forest); Spacer(Modifier.height(10.dp)); Text(value, color = text, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text(title, color = muted, fontSize = 12.sp) } }
}

@Composable private fun ActionCard(label: String, icon: ImageVector, surface: Color, text: Color, muted: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(20.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Forest); Spacer(Modifier.width(10.dp)); Text(label, color = text, fontWeight = FontWeight.Medium, fontSize = 14.sp) } }
}

@Composable private fun AppsScreen(apps: List<LaunchApp>, search: String, onSearch: (String) -> Unit, text: Color, muted: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val shown = apps.filter { it.title.contains(search, ignoreCase = true) }.take(180)
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 22.dp)) {
        Text("Your apps", color = text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Open installed applications", color = muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp))
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), contentPadding = PaddingValues(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(shown, key = { it.packageName }) { app ->
                Column(Modifier.fillMaxWidth().clickable { val i = context.packageManager.getLaunchIntentForPackage(app.packageName); if (i != null) context.startActivity(i) }.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.foundation.layout.Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE4EEE8)), contentAlignment = Alignment.Center) { Text(app.title.take(1).uppercase(), color = Forest, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(5.dp)); Text(app.title, color = text, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable private fun SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit, text: Color, muted: Color, surface: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Personalize", color = text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Make NOVA OS feel like yours", color = muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Dark appearance", color = text, fontWeight = FontWeight.SemiBold); Text("Switch NOVA OS theme", color = muted, fontSize = 12.sp) }; Switch(checked = dark, onCheckedChange = onDark) }
        }
        Spacer(Modifier.height(12.dp))
        listOf("System settings" to Settings.ACTION_SETTINGS, "Battery settings" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "Storage settings" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "Display settings" to Settings.ACTION_DISPLAY_SETTINGS, "App settings" to Settings.ACTION_APPLICATION_SETTINGS).forEach { (name, action) ->
            Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { context.startActivity(Intent(action)) }, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Settings, null, tint = Forest); Spacer(Modifier.width(12.dp)); Text(name, color = text, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = muted) } }
        }
        Spacer(Modifier.weight(1f))
        Text("NOVA OS 0.1.0 · Independent Android application", color = muted, fontSize = 11.sp)
    }
}

private fun readStats(context: Context): DeviceStats {
    val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val pct = if (scale > 0) (level * 100 / scale) else 0
    val stat = StatFs(android.os.Environment.getDataDirectory().path)
    val free = stat.availableBytes / (1024.0 * 1024 * 1024)
    val total = stat.totalBytes / (1024.0 * 1024 * 1024)
    val memory = ActivityManager.MemoryInfo()
    (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memory)
    val ram = memory.availMem / (1024.0 * 1024 * 1024)
    return DeviceStats(pct, status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL, String.format(Locale.getDefault(), "%.1f GB", free), String.format(Locale.getDefault(), "%.1f GB", total), String.format(Locale.getDefault(), "%.1f GB", ram))
}

private fun loadApps(context: Context): List<LaunchApp> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, 0).mapNotNull { info ->
        val name = info.loadLabel(context.packageManager)?.toString() ?: return@mapNotNull null
        LaunchApp(name, info.activityInfo.packageName, info.loadIcon(context.packageManager))
    }.distinctBy { it.packageName }.sortedBy { it.title.lowercase(Locale.getDefault()) }
}

private fun drawableBitmap(drawable: android.graphics.drawable.Drawable): Bitmap {
    val width = drawable.intrinsicWidth.coerceAtLeast(1)
    val height = drawable.intrinsicHeight.coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap
}
