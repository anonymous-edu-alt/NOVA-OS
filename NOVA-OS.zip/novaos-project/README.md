# NOVA OS — OPPO-compatible Android launcher prototype

An independent, lightweight Android application prototype for OPPO K14x / Android 16 / ColorOS 16. It is a new implementation and does not modify, bundle, or redistribute the supplied OneOS APK.

## Current prototype (0.1.0)
- Independent application ID: `com.novaos.launcher`
- Optional home-screen launcher role (select NOVA OS in Android's Home app settings)
- Dashboard with battery percentage/charging state, available internal storage, and available system RAM
- App list with search and launch support
- Quick links to Android Wi-Fi, Bluetooth, display, sound, battery, storage, and system settings
- Light/dark appearance switch
- No root, privileged permissions, background service, accessibility service, VPN, or device-admin role
- Dashboard stats refresh every 15 seconds while the UI is active

## Build

Requirements: Android Studio with Android SDK Platform 36, JDK 17, and Gradle 8.11.1 or compatible wrapper.

1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK Platform 36 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the OPPO K14x and test it as a normal app first. To try the home-screen role, choose NOVA OS in Settings > Apps > Default apps > Home app (wording may vary by ColorOS build).

Command line after installing Gradle: `gradle assembleDebug`.

## Important boundaries
- This is a source project, not a compiled or device-tested APK. The current execution environment has no Android SDK, Gradle, or ADB, so a signed/installable APK cannot honestly be claimed here.
- Android does not permit ordinary third-party apps to replace ColorOS system panels, status bar, lock screen, navigation gestures, OEM battery controls, or protected system services. NOVA OS links to supported Settings screens instead.
- Actual performance, battery use, launcher gesture behavior, and ColorOS 16 compatibility must be verified on the physical OPPO K14x.
- This prototype intentionally does not implement OneOS's Samsung-specific guest OS switching, root scripts, boot takeover, or system-image operations.
- The app currently uses a simple letter tile for app icons; native icon rendering and a polished adaptive icon are planned for the next iteration.

## Project structure

- `app/src/main/AndroidManifest.xml` — package visibility and optional HOME role
- `app/src/main/java/com/novaos/launcher/MainActivity.kt` — Compose UI, app discovery, system stats and settings links
- `app/build.gradle.kts` — Android / Kotlin / Compose build configuration
